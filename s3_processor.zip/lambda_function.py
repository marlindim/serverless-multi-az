def handler(event, context): return "Hello from Lambda"
